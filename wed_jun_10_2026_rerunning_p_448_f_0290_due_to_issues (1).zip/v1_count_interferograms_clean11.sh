export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== interferogram count ==="
find interferograms -maxdepth 1 -mindepth 1 -type d | wc -l

echo
echo "=== sample interferogram dirs ==="
find interferograms -maxdepth 1 -mindepth 1 -type d | sort | head -30