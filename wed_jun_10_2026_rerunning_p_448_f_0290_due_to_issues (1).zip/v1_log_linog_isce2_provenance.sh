#!/usr/bin/env bash
set -euo pipefail

echo "=== ENV PROVENANCE ==="
date
echo "HOSTNAME=$(hostname)"
echo "USER=$(whoami)"
echo "CONDA_PREFIX=${CONDA_PREFIX:-}"
echo "python3=$(which python3)"
echo "gdalinfo=$(which gdalinfo)"
echo "stackStripMap.py=$(which stackStripMap.py || true)"
python3 - <<'EOF'
import sys, isce, isceobj, osgeo
print("sys.executable =", sys.executable)
print("sys.prefix     =", sys.prefix)
print("isce           =", isce.__file__)
print("isceobj        =", isceobj.__file__)
print("osgeo          =", osgeo.__file__)
EOF