export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

grep -niE "RMSE|azimuth|range|misreg|Exception|Traceback|azpoly|rgpoly|Valid|failed|skip" \
    logs/10_run05_invertMisreg.log | head -400