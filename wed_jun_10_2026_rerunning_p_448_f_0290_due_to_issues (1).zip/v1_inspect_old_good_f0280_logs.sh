echo "=== OLD GOOD F0280: top-level ==="
ls -lah /eggraid/home/arieln/projects/linog/insar/P448/f0280

echo
echo "=== OLD GOOD F0280: refineSecondaryTiming contents ==="
find /eggraid/home/arieln/projects/linog/insar/P448/f0280/refineSecondaryTiming -maxdepth 3 -type f | sort | head -200

echo
echo "=== OLD GOOD F0280: run04 cross-correlation evidence ==="
grep -niE "valid|cross|offset|azpoly|rgpoly|misreg|RMSE|poly" \
    /eggraid/home/arieln/projects/linog/insar/P448/f0280/run04_refineSecondaryTiming.log \
    /eggraid/home/arieln/projects/linog/insar/P448/f0280/run05_invertMisreg.log \
    2>/dev/null | head -200

echo
echo "=== OLD GOOD F0280: merged + geom_reference ==="
find /eggraid/home/arieln/projects/linog/insar/P448/f0280/merged -maxdepth 2 -type f 2>/dev/null | sort | head -100
find /eggraid/home/arieln/projects/linog/insar/P448/f0280/geom_reference -maxdepth 1 -type f 2>/dev/null | sort | head -100