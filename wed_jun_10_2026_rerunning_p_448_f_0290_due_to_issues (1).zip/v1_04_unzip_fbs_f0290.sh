export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

python ~/bin/unzip_ALOS-SLC-pol.py --pol FBS \
  2>&1 | tee logs/02_unzip_fbs.log

echo
echo "=== UNZIPPED DIRS ===" | tee -a logs/02_unzip_fbs.log
find unzipped -maxdepth 1 -mindepth 1 -type d | sort | tee -a logs/02_unzip_fbs.log