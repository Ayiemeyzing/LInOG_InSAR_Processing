FRAME_DIR=/eggraid/home/arieln/projects/linog/insar/p447/f0300

echo "FRAME_DIR=$FRAME_DIR"
ls -ld "$FRAME_DIR"
ls -ld "$FRAME_DIR/SLC"
ls -ld "$FRAME_DIR/DEM"

echo
echo "=== SLC date count ==="
find "$FRAME_DIR/SLC" -maxdepth 1 -mindepth 1 -type d | wc -l

echo
echo "=== SLC dates ==="
find "$FRAME_DIR/SLC" -maxdepth 1 -mindepth 1 -type d -printf "%f\n" | sort

echo
echo "=== DEM files ==="
find "$FRAME_DIR/DEM" -maxdepth 1 -type f | sort