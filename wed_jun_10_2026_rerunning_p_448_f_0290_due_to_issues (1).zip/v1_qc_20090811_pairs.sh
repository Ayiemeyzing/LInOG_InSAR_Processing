export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== 20090811 pair shelf sizes ==="
for d in refineSecondaryTiming/pairs/*20090811*/; do
    [ -d "$d" ] || continue
    pair=$(basename "$d")
    size=$(du -sb "$d" | cut -f1)
    echo "$pair $size"
done

echo
echo "=== 20090811 log excerpts ==="
grep -ni "20090811" logs/09_run04_refineSecondaryTiming.log | head -200