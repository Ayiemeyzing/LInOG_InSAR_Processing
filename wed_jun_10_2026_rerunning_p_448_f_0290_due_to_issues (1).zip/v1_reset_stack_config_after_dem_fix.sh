export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

rm -rf configs run_files baselines pairs.pdf isce.log

mkdir -p configs run_files

stackStripMap.py -W interferogram --nofocus \
    -s SLC \
    -d DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84 \
    -t 730 -b 1500 -a 28 -r 12 -u snaphu \
    2>&1 | tee logs/05_stack_config_p1.log

echo
echo "=== CONFIG FILE COUNT ===" | tee -a logs/05_stack_config_p1.log
ls -1 configs | wc -l | tee -a logs/05_stack_config_p1.log

echo
echo "=== RUN FILES ===" | tee -a logs/05_stack_config_p1.log
ls -1 run_files | sort | tee -a logs/05_stack_config_p1.log