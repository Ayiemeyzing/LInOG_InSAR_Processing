set +e
set +u
set +o pipefail

PARENT=/eggraid/home/arieln/projects/linog/insar/p447
NEW_FRAME="${PARENT}/f0300"

mkdir -p "$NEW_FRAME"

echo "Created clean active frame:"
ls -ld "$NEW_FRAME"