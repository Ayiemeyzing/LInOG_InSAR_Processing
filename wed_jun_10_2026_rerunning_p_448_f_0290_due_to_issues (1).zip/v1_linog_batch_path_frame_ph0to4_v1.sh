#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# LInOG stripmapStack batch runner v1
#
# Scope:
#   - Preflight
#   - stackStripMap.py config generation
#   - run_01_reference
#   - run_02_focus_split
#   - run_03_geo2rdr_coarseResamp
#   - run_04_refineSecondaryTiming
#   - run_05_invertMisreg
#
# Self-heal behavior (conservative):
#   - Detect F0290-style run04/run05 poisoning
#   - If run05 fails with azpoly/rgpoly-style failure AND run04 shelves indicate
#     one dominant bad acquisition date, remove that date and retry once
#
# Stops on:
#   - unknown/new errors
#   - missing DEM
#   - invalid reference date
#   - ambiguous bad-date diagnosis
#
# Usage:
#   bash ~/linog_batch_path_frame_ph0to4_v1.sh 448 0300 [REF_DATE]
#
###############################################################################

SCRIPT_NAME="$(basename "$0")"
PATHNUM="${1:-}"
FRAMENUM="${2:-}"
REFDATE_INPUT="${3:-}"

if [[ -z "$PATHNUM" || -z "$FRAMENUM" ]]; then
    echo "Usage: bash $0 <PATHNUM> <FRAMENUM> [REF_DATE]"
    echo "Example: bash $0 448 0300 20091111"
    exit 1
fi

# Normalize
PATHNUM="$(printf "%03d" "$PATHNUM")"
FRAMENUM="$(printf "%04d" "$FRAMENUM")"

###############################################################################
# Canonical environment activation
###############################################################################
source /eggraid/home/arieln/linog_repo/env/activate_linog_isce2.sh
/eggraid/home/arieln/linog_repo/env/check_linog_isce2.sh

###############################################################################
# User/project assumptions for v1
###############################################################################
PROJECT_ROOT="/eggraid/home/arieln/projects/linog/insar"
FRAME_DIR="${PROJECT_ROOT}/p${PATHNUM}/f${FRAMENUM}"

SLC_DIR="${FRAME_DIR}/SLC"
DEM_DIR="${FRAME_DIR}/DEM"
CONFIG_DIR="${FRAME_DIR}/configs"
RUN_DIR="${FRAME_DIR}/run_files"
LOG_DIR="${FRAME_DIR}/logs"

MASTER_LOG="${LOG_DIR}/batch_v1_master.log"
RUNTIME_LOG="${LOG_DIR}/batch_v1_runtime.log"
ERROR_SUMMARY_LOG="${LOG_DIR}/batch_v1_error_summary.log"
BADDATE_LOG="${LOG_DIR}/batch_v1_bad_date_decision.log"
PROVENANCE_LOG="${LOG_DIR}/batch_v1_env_provenance.log"

mkdir -p "$LOG_DIR"

###############################################################################
# Logging / timing helpers
###############################################################################
timestamp() {
    date "+%Y-%m-%d %H:%M:%S"
}

log_msg() {
    local msg="$1"
    echo "[$(timestamp)] ${msg}" | tee -a "$MASTER_LOG"
}

phase_start() {
    local phase="$1"
    local now
    now="$(date +%s)"
    eval "START_${phase}=${now}"
    log_msg "START ${phase}"
}

phase_end() {
    local phase="$1"
    local now start elapsed
    now="$(date +%s)"
    start="$(eval "echo \${START_${phase}:-$now}")"
    elapsed=$(( now - start ))
    log_msg "END ${phase} (elapsed ${elapsed}s)"
    echo "[$(timestamp)] ${phase}: ${elapsed}s" | tee -a "$RUNTIME_LOG"
}

run_cmd_logged() {
    local label="$1"
    local logfile="$2"
    shift 2
    log_msg "RUN ${label}: $*"
    (
        set -o pipefail
        "$@" 2>&1 | tee "$logfile"
    )
}

stop_new_error() {
    local phase="$1"
    local reason="$2"
    log_msg "NEW_ERROR in ${phase}: ${reason}"
    {
        echo "[$(timestamp)] NEW_ERROR"
        echo "PHASE=${phase}"
        echo "REASON=${reason}"
    } | tee -a "$ERROR_SUMMARY_LOG"
    exit 1
}

record_known_error() {
    local phase="$1"
    local errclass="$2"
    local detail="$3"
    {
        echo "[$(timestamp)] KNOWN_ERROR"
        echo "PHASE=${phase}"
        echo "CLASS=${errclass}"
        echo "DETAIL=${detail}"
        echo "---"
    } | tee -a "$ERROR_SUMMARY_LOG"
}

###############################################################################
# Basic checks / helpers
###############################################################################
require_dir() {
    local d="$1"
    [[ -d "$d" ]] || stop_new_error "PRECHECK" "Required directory missing: $d"
}

find_dem_file() {
    find "$DEM_DIR" -maxdepth 1 -type f \( -name "*.dem.wgs84" -o -name "*.dem" \) | sort | head -1
}

list_slc_dates() {
    find "$SLC_DIR" -maxdepth 1 -mindepth 1 -type d -printf "%f\n" | sort
}

choose_reference_date() {
    local slc_dates=()
    mapfile -t slc_dates < <(list_slc_dates)

    [[ ${#slc_dates[@]} -gt 0 ]] || stop_new_error "PRECHECK" "No SLC dates found in $SLC_DIR"

    if [[ -n "$REFDATE_INPUT" ]]; then
        for d in "${slc_dates[@]}"; do
            if [[ "$d" == "$REFDATE_INPUT" ]]; then
                echo "$REFDATE_INPUT"
                return
            fi
        done
        record_known_error "PRECHECK" "REFDATE_ERROR" "Requested ref date $REFDATE_INPUT not found in SLC stack"
        stop_new_error "PRECHECK" "Requested reference date $REFDATE_INPUT not present in $SLC_DIR"
    fi

    # Conservative middle-date heuristic if user did not supply one
    local n="${#slc_dates[@]}"
    local mid=$(( n / 2 ))
    echo "${slc_dates[$mid]}"
}

patch_run01_reference() {
    local f="${RUN_DIR}/run_01_reference"
    [[ -f "$f" ]] || stop_new_error "PHASE2" "Missing $f"
    sed -i '/createWaterMask/d' "$f"
}

write_zero_watermask() {
    local logfile="$1"
    (
python3 - <<'PYEOF'
import numpy as np
from osgeo import gdal

ds = gdal.Open('geom_reference/lat.rdr')
if ds is None:
    raise RuntimeError('Could not open geom_reference/lat.rdr')

rows = ds.RasterYSize
cols = ds.RasterXSize
mask = np.zeros((rows, cols), dtype=np.uint8)
mask.tofile('geom_reference/waterMask.rdr')
print(f'waterMask.rdr written: {rows} x {cols}')
PYEOF
    ) 2>&1 | tee "$logfile"
}

qc_coreg_coarse() {
    local logfile="$1"
    {
        echo "=== coarse directories ==="
        find coregSLC/Coarse -maxdepth 2 -type d | sort
        echo
        echo "=== coarse files sample ==="
        find coregSLC/Coarse -maxdepth 2 -type f | sort | head -120
    } | tee "$logfile"
}

qc_run04_shelves() {
    local logfile="$1"
    {
        echo "=== shelve sizes ==="
        for d in refineSecondaryTiming/pairs/*/; do
            [[ -d "$d" ]] || continue
            pair="$(basename "$d")"
            size="$(du -sb "$d" | cut -f1)"
            echo "$pair $size"
        done

        echo
        echo "=== run04 log scan ==="
        grep -niE "offsets culled|Slope across|Intercept|azpoly|rgpoly|misreg|valid|gross offset|Skip Sample Across|Exception|Traceback|KeyError" \
            "${LOG_DIR}/batch_v1_phase4_run04.log" | head -400 || true
    } | tee "$logfile"
}

qc_run05_log() {
    local logfile="$1"
    grep -niE "RMSE|azimuth|range|misreg|Exception|Traceback|azpoly|rgpoly|valid|failed|skip|KeyError" \
        "${LOG_DIR}/batch_v1_phase4_run05.log" | head -400 | tee "$logfile" || true
}

classify_run05_failure() {
    local logfile="${LOG_DIR}/batch_v1_phase4_run05.log"
    if grep -q "KeyError: 'azpoly'" "$logfile"; then
        echo "AZPOLY_KEYERROR"
        return
    fi
    if grep -q "KeyError: 'rgpoly'" "$logfile"; then
        echo "RGPOLY_KEYERROR"
        return
    fi
    if grep -qiE "Traceback|Exception" "$logfile"; then
        echo "GENERIC_EXCEPTION"
        return
    fi
    echo "UNKNOWN"
}

detect_bad_date_from_run04() {
    # Heuristic:
    #  - get shelf sizes
    #  - define tiny shelves relative to median size
    #  - count repeated date participation among tiny shelves
    #  - require one dominant date
    #
    # Output:
    #   offending_date on stdout
    #
    # Exit nonzero if no clean diagnosis.

    local shelf_file
    shelf_file="$(mktemp)"

    for d in refineSecondaryTiming/pairs/*/; do
        [[ -d "$d" ]] || continue
        pair="$(basename "$d")"
        size="$(du -sb "$d" | cut -f1)"
        echo "$pair $size" >> "$shelf_file"
    done

    [[ -s "$shelf_file" ]] || return 1

    local median
    median="$(awk '{print $2}' "$shelf_file" | sort -n | awk '
        {a[NR]=$1}
        END{
            if (NR==0) exit 1
            if (NR%2==1) print a[(NR+1)/2]
            else print int((a[NR/2]+a[NR/2+1])/2)
        }'
    )" || return 1

    # Tiny if < 25% of median, conservative threshold
    local threshold=$(( median / 4 ))
    [[ "$threshold" -gt 0 ]] || return 1

    local tiny_file
    tiny_file="$(mktemp)"
    awk -v t="$threshold" '$2 < t {print $1, $2}' "$shelf_file" > "$tiny_file"

    # Need meaningful tiny shelves
    local ntiny
    ntiny="$(wc -l < "$tiny_file")"
    if [[ "$ntiny" -lt 2 ]]; then
        rm -f "$shelf_file" "$tiny_file"
        return 1
    fi

    local counts_file
    counts_file="$(mktemp)"
    awk '
    {
        split($1,a,"_")
        print a[1]
        print a[2]
    }' "$tiny_file" | sort | uniq -c | awk '{print $2, $1}' | sort -k2,2nr > "$counts_file"

    local top_date top_count second_count
    top_date="$(awk 'NR==1{print $1}' "$counts_file")"
    top_count="$(awk 'NR==1{print $2}' "$counts_file")"
    second_count="$(awk 'NR==2{print $2+0}' "$counts_file")"

    {
        echo "[$(timestamp)] run04 bad-date diagnosis"
        echo "median_shelf_size=${median}"
        echo "tiny_threshold=${threshold}"
        echo "tiny_pairs=${ntiny}"
        echo "date_counts:"
        cat "$counts_file"
        echo "---"
    } | tee -a "$BADDATE_LOG" >&2

    # Require dominance
    if [[ -n "$top_date" && "$top_count" -ge 2 && "$top_count" -gt "$second_count" ]]; then
        echo "$top_date"
        rm -f "$shelf_file" "$tiny_file" "$counts_file"
        return 0
    fi

    rm -f "$shelf_file" "$tiny_file" "$counts_file"
    return 1
}

remove_bad_date_and_reset() {
    local bad_date="$1"

    [[ -d "${SLC_DIR}/${bad_date}" ]] || stop_new_error "SELFHEAL" "Bad-date removal requested but SLC dir missing: ${bad_date}"

    record_known_error "SELFHEAL" "RUN04_BADDATE_POISONING" "Removing bad acquisition ${bad_date}"

    log_msg "Removing bad acquisition ${bad_date}"
    rm -rf "${SLC_DIR:?}/${bad_date}"

    log_msg "Wiping downstream products"
    rm -rf \
        "${CONFIG_DIR}" \
        "${RUN_DIR}" \
        "${FRAME_DIR}/baselines" \
        "${FRAME_DIR}/coregSLC" \
        "${FRAME_DIR}/offsets" \
        "${FRAME_DIR}/refineSecondaryTiming" \
        "${FRAME_DIR}/merged" \
        "${FRAME_DIR}/geom_reference"

    mkdir -p "$LOG_DIR"
}

stack_generate() {
    local dem_file="$1"
    local ref_date="$2"
    local logfile="$3"

    run_cmd_logged "stackStripMap.py" "$logfile" \
        stackStripMap.py \
        -s "$SLC_DIR" \
        -d "$dem_file" \
        -w "$FRAME_DIR" \
        -m "$ref_date"
}

preflight_inventory() {
    local logfile="$1"

    {
        echo "=== PRECHECK ==="
        echo "SCRIPT_NAME=$SCRIPT_NAME"
        echo "PATHNUM=$PATHNUM"
        echo "FRAMENUM=$FRAMENUM"
        echo "FRAME_DIR=$FRAME_DIR"
        echo "SLC_DIR=$SLC_DIR"
        echo "DEM_DIR=$DEM_DIR"
        echo "LOG_DIR=$LOG_DIR"
        echo

        echo "=== ENV ==="
        echo "CONDA_PREFIX=$CONDA_PREFIX"
        which python3
        which gdalinfo
        which stackStripMap.py
        echo

        echo "=== SLC dates ==="
        list_slc_dates || true
        echo

        echo "=== DEM contents ==="
        ls -lah "$DEM_DIR" || true
        echo
    } | tee "$logfile"
}

###############################################################################
# Main workflow with one self-heal retry max
###############################################################################
require_dir "$FRAME_DIR"
require_dir "$SLC_DIR"
require_dir "$DEM_DIR"

DEM_FILE="$(find_dem_file || true)"
[[ -n "${DEM_FILE:-}" ]] || {
    record_known_error "PRECHECK" "DEM_ERROR" "No DEM file found in $DEM_DIR"
    stop_new_error "PRECHECK" "Missing DEM in $DEM_DIR"
}

REF_DATE="$(choose_reference_date)"
log_msg "Selected REF_DATE=${REF_DATE}"

AUTO_PRUNE_USED=0

run_pipeline_attempt() {
    local attempt="$1"

    log_msg "============================================================"
    log_msg "Attempt ${attempt} for P${PATHNUM}F${FRAMENUM}"
    log_msg "FRAME_DIR=${FRAME_DIR}"
    log_msg "REF_DATE=${REF_DATE}"
    log_msg "============================================================"

    # Provenance
    {
        echo "=== ENV PROVENANCE ==="
        date
        echo "HOSTNAME=$(hostname)"
        echo "USER=$(whoami)"
        echo "CONDA_PREFIX=${CONDA_PREFIX:-}"
        echo "python3=$(which python3)"
        echo "gdalinfo=$(which gdalinfo)"
        echo "stackStripMap.py=$(which stackStripMap.py)"
        python3 - <<'PYEOF'
import sys, isce, isceobj, osgeo
print("sys.executable =", sys.executable)
print("sys.prefix     =", sys.prefix)
print("isce           =", isce.__file__)
print("isceobj        =", isceobj.__file__)
print("osgeo          =", osgeo.__file__)
PYEOF
    } | tee -a "$PROVENANCE_LOG"

    phase_start "PHASE0_PRECHECK"
    preflight_inventory "${LOG_DIR}/batch_v1_phase0_preflight.log"
    phase_end "PHASE0_PRECHECK"

    phase_start "PHASE1_STACKGEN"
    stack_generate "$DEM_FILE" "$REF_DATE" "${LOG_DIR}/batch_v1_phase1_stack.log"
    phase_end "PHASE1_STACKGEN"

    [[ -d "$CONFIG_DIR" ]] || stop_new_error "PHASE1_STACKGEN" "configs not created"
    [[ -d "$RUN_DIR" ]] || stop_new_error "PHASE1_STACKGEN" "run_files not created"

    phase_start "PHASE2_RUN01"
    patch_run01_reference

    rm -rf "${FRAME_DIR}/merged" "${FRAME_DIR}/geom_reference"
    mkdir -p "${FRAME_DIR}/merged" "${FRAME_DIR}/geom_reference"

    run_cmd_logged "run_01_reference" "${LOG_DIR}/batch_v1_phase2_run01.log" \
        bash "${RUN_DIR}/run_01_reference"

    write_zero_watermask "${LOG_DIR}/batch_v1_phase2_watermask.log"

    [[ -f "${FRAME_DIR}/geom_reference/lat.rdr" ]] || stop_new_error "PHASE2_RUN01" "lat.rdr missing after run_01"
    [[ -f "${FRAME_DIR}/geom_reference/waterMask.rdr" ]] || stop_new_error "PHASE2_RUN01" "waterMask.rdr missing after zero-mask write"
    phase_end "PHASE2_RUN01"

    phase_start "PHASE3_RUN02_RUN03"
    run_cmd_logged "run_02_focus_split" "${LOG_DIR}/batch_v1_phase3_run02.log" \
        bash "${RUN_DIR}/run_02_focus_split"

    run_cmd_logged "run_03_geo2rdr_coarseResamp" "${LOG_DIR}/batch_v1_phase3_run03.log" \
        bash "${RUN_DIR}/run_03_geo2rdr_coarseResamp"

    qc_coreg_coarse "${LOG_DIR}/batch_v1_phase3_coreg_qc.log"
    phase_end "PHASE3_RUN02_RUN03"

    phase_start "PHASE4_RUN04"
    run_cmd_logged "run_04_refineSecondaryTiming" "${LOG_DIR}/batch_v1_phase4_run04.log" \
        bash "${RUN_DIR}/run_04_refineSecondaryTiming"

    qc_run04_shelves "${LOG_DIR}/batch_v1_phase4_run04_qc.log"
    phase_end "PHASE4_RUN04"

    phase_start "PHASE4_RUN05"
    set +e
    bash "${RUN_DIR}/run_05_invertMisreg" 2>&1 | tee "${LOG_DIR}/batch_v1_phase4_run05.log"
    local run05_rc=$?
    set -e

    qc_run05_log "${LOG_DIR}/batch_v1_phase4_run05_qc.log"

    if [[ $run05_rc -ne 0 ]]; then
        local failure_class
        failure_class="$(classify_run05_failure)"

        if [[ "$AUTO_PRUNE_USED" -eq 0 && ( "$failure_class" == "AZPOLY_KEYERROR" || "$failure_class" == "RGPOLY_KEYERROR" ) ]]; then
            record_known_error "PHASE4_RUN05" "RUN05_POLY_FAILURE" "Detected ${failure_class}; attempting bad-date diagnosis"

            local bad_date
            if bad_date="$(detect_bad_date_from_run04)"; then
                log_msg "Detected dominant bad date from run04 shelves: ${bad_date}"
                AUTO_PRUNE_USED=1
                remove_bad_date_and_reset "$bad_date"

                # Recompute DEM / refdate state for retry
                DEM_FILE="$(find_dem_file || true)"
                [[ -n "${DEM_FILE:-}" ]] || stop_new_error "SELFHEAL" "DEM missing after reset"

                # If removed date was reference date or ref date missing, choose new one
                if [[ ! -d "${SLC_DIR}/${REF_DATE}" ]]; then
                    REF_DATE="$(choose_reference_date)"
                    log_msg "Reference date was removed/unavailable; new REF_DATE=${REF_DATE}"
                fi

                phase_end "PHASE4_RUN05"
                return 99
            else
                stop_new_error "PHASE4_RUN05" "Known run05 poly failure but run04 bad-date diagnosis was ambiguous"
            fi
        else
            stop_new_error "PHASE4_RUN05" "run_05 failed with class=${failure_class}"
        fi
    fi

    # Success criteria
    if ! grep -q "RMSE in azimuth" "${LOG_DIR}/batch_v1_phase4_run05.log"; then
        stop_new_error "PHASE4_RUN05" "run_05 finished but RMSE in azimuth not found"
    fi
    if ! grep -q "RMSE in range" "${LOG_DIR}/batch_v1_phase4_run05.log"; then
        stop_new_error "PHASE4_RUN05" "run_05 finished but RMSE in range not found"
    fi

    phase_end "PHASE4_RUN05"
    return 0
}

ATTEMPT=1
while true; do
    set +e
    run_pipeline_attempt "$ATTEMPT"
    RC=$?
    set -e

    if [[ "$RC" -eq 0 ]]; then
        log_msg "SUCCESS: P${PATHNUM}F${FRAMENUM} completed through run_05"
        exit 0
    elif [[ "$RC" -eq 99 ]]; then
        ATTEMPT=$(( ATTEMPT + 1 ))
        log_msg "Retrying after self-heal date removal (attempt ${ATTEMPT})"
        continue
    else
        stop_new_error "MAIN" "Unexpected control-flow return code ${RC}"
    fi
done