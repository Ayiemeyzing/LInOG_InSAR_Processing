export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== reference config ==="
grep -nE "output|lat_file|lon_file|waterMask|geom" configs/config_reference_* 2>/dev/null

echo
echo "=== geo2rdr coarse config sample ==="
grep -nE "geom|coreg|reference|secondary" configs/config_geo2rdr_coarseResamp_* 2>/dev/null | head -80

echo
echo "=== refineSecondaryTiming sample ==="
grep -nE "reference|secondary|outfile" configs/config_refineSecondaryTiming_* 2>/dev/null | head -80