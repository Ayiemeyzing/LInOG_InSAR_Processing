export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

sh run_files/run_05_invertMisreg 2>&1 | tee logs/10_run05_invertMisreg.log