export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

sh run_files/run_07_grid_baseline 2>&1 | tee logs/12_run07_grid_baseline_clean11.log