FRAME_DIR=/eggraid/home/arieln/projects/linog/insar/p447/f0300

echo "=== top-level contents ==="
find "$FRAME_DIR" -maxdepth 1 -mindepth 1 -printf "%f\n" | sort

echo
echo "=== should be empty input/staging dirs for now ==="
for d in raw unzipped SLC DEM logs manual_run_logs qc tmp; do
    echo "--- $d ---"
    find "$FRAME_DIR/$d" -maxdepth 2 -mindepth 1 2>/dev/null | head -20
done

echo
echo "=== generated products should NOT exist ==="
for d in configs run_files baselines coregSLC geom_reference Igrams interferograms merged offsets refineSecondaryTiming rejected_pairs mintpy mintpy_logs; do
    if [[ -e "$FRAME_DIR/$d" ]]; then
        echo "WARNING: generated product exists: $d"
    else
        echo "OK absent: $d"
    fi
done