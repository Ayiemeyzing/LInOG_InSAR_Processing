set +e
set +u
set +o pipefail

linog_isce2
bash ~/linog_batch_path_frame_ph0to4_v1.sh 447 0300