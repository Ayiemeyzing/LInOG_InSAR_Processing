linog_isce2() {
    source /eggraid/home/arieln/linog_repo/env/activate_linog_isce2.sh
}