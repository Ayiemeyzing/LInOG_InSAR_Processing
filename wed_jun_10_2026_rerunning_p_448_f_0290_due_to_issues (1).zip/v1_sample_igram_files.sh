export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

find interferograms -type f | grep -E "filt_.*\.int$" | head -10