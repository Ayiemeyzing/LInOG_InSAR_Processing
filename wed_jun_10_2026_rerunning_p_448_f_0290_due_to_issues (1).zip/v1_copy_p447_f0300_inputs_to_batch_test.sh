SRC=/eggraid/home/arieln/projects/linog/insar/p447/f0300
TEST=/eggraid/home/arieln/projects/linog/insar/p447/f0300_batch_v1_test

mkdir -p "$TEST/SLC" "$TEST/DEM"

echo "Copying SLC..."
rsync -aH --info=progress2 "$SRC/SLC/" "$TEST/SLC/"

echo "Copying DEM..."
rsync -aH --info=progress2 "$SRC/DEM/" "$TEST/DEM/"

mkdir -p "$TEST/logs"

echo
echo "=== copied test folder ==="
find "$TEST" -maxdepth 2 -type d | sort

echo
echo "=== copied SLC count ==="
find "$TEST/SLC" -maxdepth 1 -mindepth 1 -type d | wc -l

echo
echo "=== copied DEM files ==="
find "$TEST/DEM" -maxdepth 1 -type f | sort

echo
echo "=== ensure SLC and DEM are not symlinks ==="
[[ ! -L "$TEST/SLC" ]] && echo "SLC is real directory"
[[ ! -L "$TEST/DEM" ]] && echo "DEM is real directory"