SRC=/eggraid/home/arieln/projects/linog/insar/p447/f0300
TEST=/eggraid/home/arieln/projects/linog/insar/p447/f0300_batch_v1_test

if [[ -e "$TEST" ]]; then
    echo "STOP: test folder already exists:"
    echo "$TEST"
    echo "Move or remove it manually if you want to recreate it."
else
    mkdir -p "$TEST"
    echo "Created clean test folder:"
    echo "$TEST"
fi

ls -ld "$TEST"