FRAME_DIR=/eggraid/home/arieln/projects/linog/insar/p447/f0300

echo "=== remaining frame contents ==="
find "$FRAME_DIR" -maxdepth 2 -type d | sort

echo
echo "=== SLC count still preserved ==="
find "$FRAME_DIR/SLC" -maxdepth 1 -mindepth 1 -type d | wc -l

echo
echo "=== DEM still preserved ==="
find "$FRAME_DIR/DEM" -maxdepth 1 -type f | sort