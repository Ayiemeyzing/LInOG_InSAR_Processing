source /eggraid/home/arieln/linog_repo/env/activate_linog_isce2.sh
/eggraid/home/arieln/linog_repo/env/check_linog_isce2.sh
stackStripMap.py -h | head -40