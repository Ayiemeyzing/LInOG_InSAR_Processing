echo "=== shell ==="
echo "$SHELL"
echo

echo "=== interactive flags ==="
echo "$-"
echo

echo "=== bash version ==="
bash --version | head -1
echo

echo "=== aliases affecting ls/git ==="
alias ls 2>/dev/null || true
alias git 2>/dev/null || true
echo

echo "=== completion settings ==="
bind -v | grep -E "completion|show-all-if-ambiguous|menu-complete|bell-style" || true
echo

echo "=== bashrc snippets mentioning completion ==="
grep -niE "bash_completion|complete -|bind |PROMPT_COMMAND|trap |stty|git" ~/.bashrc ~/.profile ~/.bash_aliases 2>/dev/null || true