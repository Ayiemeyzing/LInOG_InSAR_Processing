TEST=/eggraid/home/arieln/projects/linog/insar/p447/f0300_batch_v1_test

echo "=== master log ==="
cat "$TEST/logs/batch_v1_master.log" 2>/dev/null || true

echo
echo "=== preflight ==="
cat "$TEST/logs/batch_v1_phase0_preflight.log" 2>/dev/null || true

echo
echo "=== stack log ==="
cat "$TEST/logs/batch_v1_phase1_stack.log" 2>/dev/null || true

echo
echo "=== error summary ==="
cat "$TEST/logs/batch_v1_error_summary.log" 2>/dev/null || true