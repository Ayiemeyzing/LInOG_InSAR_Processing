source /eggraid/miniconda3/etc/profile.d/conda.sh
conda create -y -p /eggraid/miniconda3/envs/linog_isce2 --clone /eggraid/miniconda3/envs/isce2