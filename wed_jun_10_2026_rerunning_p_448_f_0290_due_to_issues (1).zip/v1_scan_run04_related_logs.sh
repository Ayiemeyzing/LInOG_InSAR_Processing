grep -RniE "refineSecondaryTiming|azpoly|rgpoly|valid.*cross|empty shel|shelve|misreg|offset" \
    /eggraid/home/$USER/projects/linog/insar/448/0290 \
    /eggraid/home/$USER/projects/linog/insar/p448/f0290 \
    2>/dev/null | tee ~/p448_f0290_run04_scan_20260609.log