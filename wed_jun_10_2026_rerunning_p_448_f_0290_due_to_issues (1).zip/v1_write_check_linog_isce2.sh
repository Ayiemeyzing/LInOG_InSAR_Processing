cat > /eggraid/home/arieln/linog_repo/env/check_linog_isce2.sh <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

EXPECTED="/eggraid/miniconda3/envs/linog_isce2"

fail() {
  echo "ENVIRONMENT_ERROR: $1" >&2
  exit 1
}

[[ "${CONDA_PREFIX:-}" == "$EXPECTED" ]] || fail "CONDA_PREFIX is not $EXPECTED"

PY=$(which python3 || true)
GDAL=$(which gdalinfo || true)
STACK=$(which stackStripMap.py || true)

[[ "$PY" == "$EXPECTED/bin/python3" ]] || fail "python3 resolves to $PY"
[[ "$GDAL" == "$EXPECTED/bin/gdalinfo" ]] || fail "gdalinfo resolves to $GDAL"
[[ "$STACK" == "$EXPECTED/share/isce2/stripmapStack/stackStripMap.py" ]] || fail "stackStripMap.py resolves to $STACK"

python3 - <<'PYEOF'
import sys
expected = "/eggraid/miniconda3/envs/linog_isce2"
mods = ["isce", "isceobj", "osgeo", "numpy", "scipy"]
bad = []

if sys.prefix != expected:
    bad.append(f"sys.prefix={sys.prefix}")

for m in mods:
    mod = __import__(m)
    path = getattr(mod, "__file__", "")
    if expected not in path:
        bad.append(f"{m} from {path}")

if bad:
    raise SystemExit(" ; ".join(bad))
print("Environment provenance check passed.")
PYEOF

echo "linog_isce2 environment check passed."
EOF

chmod +x /eggraid/home/arieln/linog_repo/env/check_linog_isce2.sh
ls -l /eggraid/home/arieln/linog_repo/env/check_linog_isce2.sh