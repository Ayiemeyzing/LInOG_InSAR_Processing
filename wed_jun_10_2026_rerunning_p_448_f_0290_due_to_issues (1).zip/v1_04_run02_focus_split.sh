export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

sh run_files/run_02_focus_split 2>&1 | tee logs/07_run02_focus_split.log