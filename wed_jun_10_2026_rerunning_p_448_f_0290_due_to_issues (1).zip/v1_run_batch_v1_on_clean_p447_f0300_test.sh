linog_isce2

LINOG_FRAME_DIR_OVERRIDE=/eggraid/home/arieln/projects/linog/insar/p447/f0300_batch_v1_test \
bash ~/linog_batch_path_frame_ph0to4_v1_scratch.sh 447 0300