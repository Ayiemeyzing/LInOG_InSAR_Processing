cat > /eggraid/home/arieln/linog_repo/env/activate_linog_isce2.sh <<'EOF'
#!/usr/bin/env bash
set -eo pipefail

# Clear conflicting state from personal / legacy environments
unset PYTHONPATH || true
unset ISCE_HOME || true
unset ISCEDB || true

source /eggraid/miniconda3/etc/profile.d/conda.sh
conda activate /eggraid/miniconda3/envs/linog_isce2

# Canonical ISCE paths from the shared env
export ISCE_HOME="/eggraid/miniconda3/envs/linog_isce2/lib/python3.11/site-packages/isce"
export PATH="/eggraid/miniconda3/envs/linog_isce2/share/isce2/stripmapStack:/eggraid/miniconda3/envs/linog_isce2/lib/python3.11/site-packages/isce/applications:/eggraid/miniconda3/envs/linog_isce2/lib/python3.11/site-packages/isce/bin:$PATH"
export PYTHONPATH="/eggraid/miniconda3/envs/linog_isce2/lib/python3.11/site-packages/isce/components:/eggraid/miniconda3/envs/linog_isce2/share/isce2:/eggraid/miniconda3/envs/linog_isce2/lib/python3.11/site-packages/isce"

echo "Activated linog_isce2"
echo "CONDA_PREFIX=$CONDA_PREFIX"
echo "python3=$(which python3)"
echo "gdalinfo=$(which gdalinfo)"
echo "stackStripMap.py=$(which stackStripMap.py)"
EOF

chmod +x /eggraid/home/arieln/linog_repo/env/activate_linog_isce2.sh
ls -l /eggraid/home/arieln/linog_repo/env/activate_linog_isce2.sh