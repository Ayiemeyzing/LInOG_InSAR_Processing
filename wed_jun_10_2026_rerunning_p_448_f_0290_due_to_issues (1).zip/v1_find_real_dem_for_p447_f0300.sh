FRAME_DIR=/eggraid/home/arieln/projects/linog/insar/p447/f0300
ARCHIVE_ROOT=/eggraid/home/arieln/projects/linog/insar/p447/archive_f0300_old_runs
PROJECT_ROOT=/eggraid/home/arieln/projects/linog/insar

echo "=== DEM candidates inside clean f0300 ==="
find "$FRAME_DIR" -type f \( -name "*.dem" -o -name "*.dem.wgs84" -o -name "*.hgt" \) 2>/dev/null | sort

echo
echo "=== DEM candidates inside archived old f0300 ==="
find "$ARCHIVE_ROOT" -type f \( -name "*.dem" -o -name "*.dem.wgs84" -o -name "*.hgt" \) 2>/dev/null | sort | head -100

echo
echo "=== DEM candidates nearby under project ==="
find "$PROJECT_ROOT" -type f \( -name "*.dem" -o -name "*.dem.wgs84" -o -name "*.hgt" \) 2>/dev/null | sort | head -200