export SRC=/eggraid/home/arieln/projects/linog/insar/p448/f0280
export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290

mkdir -p "${WDIR}/DEM"

cp -v "${SRC}"/DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84* "${WDIR}/DEM/"

echo
echo "=== DEM after fallback copy ==="
ls -lah "${WDIR}/DEM"