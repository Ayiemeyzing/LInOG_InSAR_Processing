export WDIR=/eggraid/home/$USER/projects/linog/insar/p448/f0290

mkdir -p "${WDIR}/manual_run_logs"
date +"%Y%m%d_%H%M%S" | tee "${WDIR}/manual_run_logs/00_reset_timestamp.txt"

cd "${WDIR}"

# optional backup folder
STAMP=$(date +"%Y%m%d_%H%M%S")
mkdir -p "_backup_pre_manual_${STAMP}"

for d in geom_reference run_files interferograms Igrams DEM unzipped baselines \
         mintpy mintpy_logs rejected_pairs refineSecondaryTiming misreg logs merged
do
    if [ -e "$d" ]; then
        mv "$d" "_backup_pre_manual_${STAMP}/"
    fi
done

mkdir -p logs manual_run_logs
echo "Reset complete at ${STAMP}" | tee "manual_run_logs/00_reset_complete_${STAMP}.log"

echo "Preserved folders:"
ls -ld raw SLC data 2>/dev/null