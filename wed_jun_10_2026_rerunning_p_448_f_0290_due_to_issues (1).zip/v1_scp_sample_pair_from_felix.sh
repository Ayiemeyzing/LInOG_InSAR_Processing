mkdir -p ~/LInOG/insar/p448/f0290/Igrams
scp -r arieln@felix:/eggraid/home/arieln/projects/linog/insar/p448/f0290/Igrams/20091111_20091227 \
  ~/LInOG/insar/p448/f0290/Igrams/