set +e
set +u
set +o pipefail

echo "flags=$-"
set -o | grep -E 'errexit|nounset|pipefail'