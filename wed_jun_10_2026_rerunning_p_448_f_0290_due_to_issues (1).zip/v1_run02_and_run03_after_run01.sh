export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

sh run_files/run_02_focus_split 2>&1 | tee logs/07_run02_focus_split.log
sh run_files/run_03_geo2rdr_coarseResamp 2>&1 | tee logs/08_run03_geo2rdr_coarseResamp.log