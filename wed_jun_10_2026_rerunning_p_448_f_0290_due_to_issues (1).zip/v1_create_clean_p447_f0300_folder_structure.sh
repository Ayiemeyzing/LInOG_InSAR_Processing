set +e
set +u
set +o pipefail

FRAME_DIR=/eggraid/home/arieln/projects/linog/insar/p447/f0300

mkdir -p "$FRAME_DIR"

# Input / staging directories
mkdir -p "$FRAME_DIR/raw"
mkdir -p "$FRAME_DIR/unzipped"
mkdir -p "$FRAME_DIR/SLC"
mkdir -p "$FRAME_DIR/DEM"

# Logs and manual notes
mkdir -p "$FRAME_DIR/logs"
mkdir -p "$FRAME_DIR/manual_run_logs"

# Optional scratch/QC bookkeeping directories
mkdir -p "$FRAME_DIR/qc"
mkdir -p "$FRAME_DIR/tmp"

echo "Created clean from-scratch folder structure:"
find "$FRAME_DIR" -maxdepth 2 -type d | sort