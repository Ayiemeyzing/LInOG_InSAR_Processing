export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== coarse directories ==="
find coregSLC/Coarse -maxdepth 2 -type d | sort

echo
echo "=== coarse files sample ==="
find coregSLC/Coarse -maxdepth 2 -type f | sort | head -120