TEST=/eggraid/home/arieln/projects/linog/insar/p447/f0300_batch_v1_test

echo "=== run04 QC ==="
cat "$TEST/logs/batch_v1_phase4_run04_qc.log" 2>/dev/null || true

echo
echo "=== run05 QC ==="
cat "$TEST/logs/batch_v1_phase4_run05_qc.log" 2>/dev/null || true

echo
echo "=== bad date decision ==="
cat "$TEST/logs/batch_v1_bad_date_decision.log" 2>/dev/null || true