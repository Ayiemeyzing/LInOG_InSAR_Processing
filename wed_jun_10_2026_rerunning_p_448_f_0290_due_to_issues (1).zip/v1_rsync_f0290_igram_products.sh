mkdir -p ~/LInOG/insar/p448/f0290/Igrams

rsync -avh --progress \
  arieln@felix:/eggraid/home/arieln/projects/linog/insar/p448/f0290/Igrams/*/filt_* \
  ~/LInOG/insar/p448/f0290/Igrams/