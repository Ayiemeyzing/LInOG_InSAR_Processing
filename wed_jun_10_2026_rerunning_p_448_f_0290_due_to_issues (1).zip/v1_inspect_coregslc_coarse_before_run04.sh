export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== Coarse dirs ==="
find coregSLC/Coarse -maxdepth 2 -type d | sort

echo
echo "=== Coarse SLC files ==="
find coregSLC/Coarse -maxdepth 2 -type f | sort | head -100