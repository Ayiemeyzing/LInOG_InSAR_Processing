export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== reference config files ==="
ls configs/config_reference_*

echo
echo "=== config_reference_20091111 ==="
grep -nE "reference|output|lat_file|lon_file|waterMask" configs/config_reference_20091111 2>/dev/null

echo
echo "=== geo2rdr sample (reference should be 20091111) ==="
grep -nE "reference : |secondary : |geom : |coreg :" configs/config_geo2rdr_coarseResamp_* | head -60

echo
echo "=== run_01 first lines ==="
head -40 run_files/run_01_reference