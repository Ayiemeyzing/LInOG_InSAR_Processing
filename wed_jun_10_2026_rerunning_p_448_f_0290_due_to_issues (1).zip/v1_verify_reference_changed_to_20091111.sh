export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== reference config ==="
grep -nE "output|lat_file|lon_file|waterMask|reference" configs/config_reference_* 2>/dev/null

echo
echo "=== geo2rdr sample (should reference 20091111) ==="
grep -nE "reference : |secondary : |geom : |coreg :" configs/config_geo2rdr_coarseResamp_* 2>/dev/null | head -40

echo
echo "=== run_01 header ==="
head -40 run_files/run_01_reference