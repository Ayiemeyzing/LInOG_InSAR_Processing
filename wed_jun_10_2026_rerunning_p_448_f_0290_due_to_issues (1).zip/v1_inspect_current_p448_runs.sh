for F in f0280 f0290; do
  WDIR=/eggraid/home/arieln/projects/linog/insar/p448/$F
  echo "=================================================="
  echo "FRAME: $F"
  echo "WDIR:  $WDIR"
  echo "=================================================="

  echo "--- top level ---"
  ls -lah "$WDIR" 2>/dev/null

  echo
  echo "--- logs ---"
  find "$WDIR/logs" -maxdepth 1 -type f 2>/dev/null | sort

  echo
  echo "--- run_files ---"
  find "$WDIR/run_files" -maxdepth 1 -type f 2>/dev/null | sort

  echo
  echo "--- refineSecondaryTiming files ---"
  find "$WDIR/refineSecondaryTiming" -maxdepth 3 -type f 2>/dev/null | sort | head -200

  echo
  echo "--- merged + geom_reference ---"
  find "$WDIR/merged" -maxdepth 2 -type f 2>/dev/null | sort | head -100
  find "$WDIR/geom_reference" -maxdepth 1 -type f 2>/dev/null | sort | head -100

  echo
done