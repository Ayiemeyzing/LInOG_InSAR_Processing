export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

{
  echo "=== shelve sizes ==="
  for d in refineSecondaryTiming/pairs/*/; do
      pair=$(basename "$d")
      size=$(du -sb "$d" | cut -f1)
      echo "$pair $size"
  done

  echo
  echo "=== run04 log scan ==="
  grep -niE "offsets culled|Slope across|Intercept|azpoly|rgpoly|misreg|valid|gross offset|Skip Sample Across|Exception|Traceback" \
      logs/09_run04_refineSecondaryTiming_no20090811.log | head -300
} | tee logs/09b_run04_qc_no20090811.log