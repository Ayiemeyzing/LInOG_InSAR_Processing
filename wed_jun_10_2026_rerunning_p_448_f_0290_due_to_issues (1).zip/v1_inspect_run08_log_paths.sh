export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

grep -niE "Igrams|interferograms|topophase|filt|phsig|unw|writing|mkdir|pair" \
    logs/13_run08_igram_clean11.log | head -400