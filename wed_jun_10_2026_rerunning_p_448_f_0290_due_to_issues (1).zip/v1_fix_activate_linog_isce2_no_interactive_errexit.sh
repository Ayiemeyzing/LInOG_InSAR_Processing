cat > /eggraid/home/arieln/linog_repo/env/activate_linog_isce2.sh <<'EOF'
#!/usr/bin/env bash
# LInOG shared ISCE2 activation wrapper.
#
# IMPORTANT:
# This file is intended to be SOURCED from an interactive shell.
# Therefore it must NOT leave `set -e`, `set -u`, or `set -o pipefail`
# changed in the caller's shell. Otherwise normal command failures can
# terminate the SSH session.

TARGET_ENV="/eggraid/miniconda3/envs/linog_isce2"

# Preserve caller nounset state because conda hooks may reference optional vars.
_LINOG_HAD_NOUNSET=0
case "$-" in
    *u*) _LINOG_HAD_NOUNSET=1 ;;
esac

_linog_restore_nounset() {
    if [[ "${_LINOG_HAD_NOUNSET}" -eq 1 ]]; then
        set -u
    else
        set +u
    fi
}

_linog_fail() {
    local msg="$1"
    _linog_restore_nounset
    echo "ENVIRONMENT_ERROR: ${msg}" >&2
    return 1 2>/dev/null || exit 1
}

# Clear conflicting state from personal / legacy environments.
unset PYTHONPATH || true
unset ISCE_HOME || true
unset ISCEDB || true

# Activate only if not already in the target env.
# Temporarily disable nounset around conda hook internals.
if [[ "${CONDA_PREFIX:-}" != "$TARGET_ENV" ]]; then
    set +u

    if [[ ! -f /eggraid/miniconda3/etc/profile.d/conda.sh ]]; then
        _linog_fail "Missing conda hook: /eggraid/miniconda3/etc/profile.d/conda.sh"
    fi

    source /eggraid/miniconda3/etc/profile.d/conda.sh || \
        _linog_fail "Failed to source conda hook"

    conda activate "$TARGET_ENV" || \
        _linog_fail "Failed to activate $TARGET_ENV"

    _linog_restore_nounset
fi

# Canonical ISCE paths from the shared env.
export ISCE_HOME="${TARGET_ENV}/lib/python3.11/site-packages/isce"
export PYTHONPATH="${TARGET_ENV}/lib/python3.11/site-packages/isce/components:${TARGET_ENV}/share/isce2:${TARGET_ENV}/lib/python3.11/site-packages/isce"

# Put canonical ISCE tools first without endlessly duplicating entries.
_linog_path_remove() {
    local remove="$1"
    local old=":${PATH:-}:"
    old="${old//:${remove}:/:}"
    old="${old#:}"
    old="${old%:}"
    PATH="$old"
}

_linog_path_remove "${TARGET_ENV}/share/isce2/stripmapStack"
_linog_path_remove "${TARGET_ENV}/lib/python3.11/site-packages/isce/applications"
_linog_path_remove "${TARGET_ENV}/lib/python3.11/site-packages/isce/bin"

export PATH="${TARGET_ENV}/share/isce2/stripmapStack:${TARGET_ENV}/lib/python3.11/site-packages/isce/applications:${TARGET_ENV}/lib/python3.11/site-packages/isce/bin:${PATH}"

echo "Activated linog_isce2"
echo "CONDA_PREFIX=${CONDA_PREFIX:-}"
echo "python3=$(which python3)"
echo "gdalinfo=$(which gdalinfo)"
echo "stackStripMap.py=$(which stackStripMap.py)"

return 0 2>/dev/null || exit 0
EOF

chmod +x /eggraid/home/arieln/linog_repo/env/activate_linog_isce2.sh