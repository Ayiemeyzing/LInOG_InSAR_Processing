export PATH_NUM=448
export FRAME_NUM=0290
export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290

cd "${WDIR}"

find_alos.sh "$PATH_NUM" "$FRAME_NUM" /eggraid/data/alos raw/ \
  2>&1 | tee logs/01_find_alos.log

mv raw/${PATH_NUM}/${FRAME_NUM}/data/*.zip raw/ 2>/dev/null || true
rm -rf raw/${PATH_NUM}

echo
echo "=== RAW ZIPS ===" | tee -a logs/01_find_alos.log
ls -1 raw | tee -a logs/01_find_alos.log