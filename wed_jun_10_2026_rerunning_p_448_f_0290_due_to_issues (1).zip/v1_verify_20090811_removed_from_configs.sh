export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== any 20090811 still in configs? ==="
grep -Rni "20090811" configs run_files 2>/dev/null || echo "No 20090811 found in configs/run_files"

echo
echo "=== reference config ==="
grep -nE "reference|output|lat_file|lon_file|waterMask" configs/config_reference_20091111 2>/dev/null