source /opt/miniforge3/bin/activate
conda activate isce2
source ~/isce2.rc

export PATH_NUM=448
export FRAME_NUM=0290
export PADDED_PATH=p${PATH_NUM}
export PADDED_FRAME=f${FRAME_NUM}
export FRAME_TAG=P${PATH_NUM}F${FRAME_NUM}
export WORK_DIR=/eggraid/home/$USER/projects/linog/insar/${PADDED_PATH}/${PADDED_FRAME}

echo "=== WORK_DIR ==="
echo "$WORK_DIR"

echo
echo "=== TOP LEVEL ==="
ls -lah "$WORK_DIR"

echo
echo "=== SLC DATES ==="
ls -1 "$WORK_DIR/SLC" 2>/dev/null | sort

echo
echo "=== LOG FILES ==="
ls -lah "$WORK_DIR/logs" 2>/dev/null

echo
echo "=== RUN FILES ==="
ls -lah "$WORK_DIR/run_files" 2>/dev/null

echo
echo "=== OLD 3-DIGIT PATH CHECK ==="
ls -lah /eggraid/home/$USER/projects/linog/insar/448/0290 2>/dev/null || echo "old 448/0290 path not found"

echo
echo "=== SEARCH OLD P448/F0290 LOGS ==="
find /eggraid/home/$USER/projects/linog/insar -maxdepth 4 \( -path "*/448/0290/*" -o -path "*/p448/f0290/*" \) -type f | sort