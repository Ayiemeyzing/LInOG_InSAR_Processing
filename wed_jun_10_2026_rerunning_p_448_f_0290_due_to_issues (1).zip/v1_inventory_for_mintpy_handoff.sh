export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== geometry files ==="
find geom_reference merged/geom_reference -maxdepth 1 -type f 2>/dev/null | sort

echo
echo "=== sample unwrapped files ==="
find Igrams -type f | grep "_snaphu.unw$" | sort | head -20

echo
echo "=== sample coherence files ==="
find Igrams -type f | grep "filt_.*\.cor$" | sort | head -20