cp ~/linog_batch_path_frame_ph0to4_v1.sh ~/linog_batch_path_frame_ph0to4_v1.sh.bak_badslc_$(date +%Y%m%d_%H%M%S)

python3 - <<'PYEOF'
from pathlib import Path

p = Path.home() / "linog_batch_path_frame_ph0to4_v1.sh"
s = p.read_text()

old = '''    log_msg "Removing bad acquisition ${bad_date}"
    rm -rf "${SLC_DIR:?}/${bad_date}"'''

new = '''    log_msg "Moving bad acquisition ${bad_date} out of active SLC directory"
    BAD_SLC_BACKUP="${FRAME_DIR}/bad_slc_removed_by_batch_v1"
    mkdir -p "$BAD_SLC_BACKUP"

    if [[ -e "${BAD_SLC_BACKUP}/${bad_date}" ]]; then
        stop_new_error "SELFHEAL" "Backup for bad SLC date already exists: ${BAD_SLC_BACKUP}/${bad_date}"
    fi

    mv "${SLC_DIR}/${bad_date}" "${BAD_SLC_BACKUP}/${bad_date}"'''

if old not in s:
    raise SystemExit("Could not find bad-date rm block to patch")

s = s.replace(old, new)
p.write_text(s)
PYEOF

bash -n ~/linog_batch_path_frame_ph0to4_v1.sh
grep -n "Moving bad acquisition" -A10 -B5 ~/linog_batch_path_frame_ph0to4_v1.sh