cp ~/linog_batch_path_frame_ph0to4_v1.sh ~/linog_batch_path_frame_ph0to4_v1.sh.bak_$(date +%Y%m%d_%H%M%S)

python3 - <<'PYEOF'
from pathlib import Path

p = Path.home() / "linog_batch_path_frame_ph0to4_v1.sh"
s = p.read_text()

s = s.replace(
    'PATHNUM="$(printf "%03d" "$PATHNUM")"\nFRAMENUM="$(printf "%04d" "$FRAMENUM")"',
    'PATHNUM="$(printf "%03d" "$((10#$PATHNUM))")"\nFRAMENUM="$(printf "%04d" "$((10#$FRAMENUM))")"'
)

p.write_text(s)
PYEOF

grep -nE 'PATHNUM=|FRAMENUM=' ~/linog_batch_path_frame_ph0to4_v1.sh | head -20
bash -n ~/linog_batch_path_frame_ph0to4_v1.sh