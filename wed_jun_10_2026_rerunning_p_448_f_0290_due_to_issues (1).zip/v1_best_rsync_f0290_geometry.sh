mkdir -p ~/LInOG/insar/p448/f0290/geom_reference

rsync -avh --progress \
  arieln@felix:/eggraid/home/arieln/projects/linog/insar/p448/f0290/geom_reference/ \
  ~/LInOG/insar/p448/f0290/geom_reference/