export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

python3 - <<'EOF' 2>&1 | tee logs/06b_create_zero_watermask.log
import numpy as np
from osgeo import gdal

ds = gdal.Open('geom_reference/lat.rdr')
if ds is None:
    raise RuntimeError('Could not open geom_reference/lat.rdr')

rows = ds.RasterYSize
cols = ds.RasterXSize
mask = np.zeros((rows, cols), dtype=np.uint8)
mask.tofile('geom_reference/waterMask.rdr')
print(f'waterMask.rdr written: {rows} x {cols}')
EOF

echo
echo "=== waterMask files ==="
ls -lah geom_reference/waterMask.rdr*