echo "=== search in home env ==="
find /home/arieln/.conda/envs/isce2 -type f \( -name "stackStripMap.py" -o -name "stripmapWrapper.py" -o -name "createWaterMask.py" -o -name "invertMisreg.py" \) 2>/dev/null | sort

echo
echo "=== search in eggraid env ==="
find /eggraid/miniconda3/envs/isce2 -type f \( -name "stackStripMap.py" -o -name "stripmapWrapper.py" -o -name "createWaterMask.py" -o -name "invertMisreg.py" \) 2>/dev/null | sort