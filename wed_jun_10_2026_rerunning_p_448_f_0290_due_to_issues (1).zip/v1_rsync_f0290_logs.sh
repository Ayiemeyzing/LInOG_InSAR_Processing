mkdir -p ~/LInOG/insar/p448/f0290/logs

rsync -avh --progress \
  arieln@felix:/eggraid/home/arieln/projects/linog/insar/p448/f0290/logs/ \
  ~/LInOG/insar/p448/f0290/logs/