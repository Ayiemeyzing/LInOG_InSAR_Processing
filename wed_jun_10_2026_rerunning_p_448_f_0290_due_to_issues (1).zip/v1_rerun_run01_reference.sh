export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

sh run_files/run_01_reference 2>&1 | tee logs/06_run01_reference_retry.log