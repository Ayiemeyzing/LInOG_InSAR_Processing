cp ~/linog_batch_path_frame_ph0to4_v1.sh ~/linog_batch_path_frame_ph0to4_v1_scratch.sh

python3 - <<'PYEOF'
from pathlib import Path

p = Path.home() / "linog_batch_path_frame_ph0to4_v1_scratch.sh"
s = p.read_text()

old = '''PROJECT_ROOT="/eggraid/home/arieln/projects/linog/insar"
FRAME_DIR="${PROJECT_ROOT}/p${PATHNUM}/f${FRAMENUM}"'''

new = '''PROJECT_ROOT="/eggraid/home/arieln/projects/linog/insar"
FRAME_DIR="${PROJECT_ROOT}/p${PATHNUM}/f${FRAMENUM}"

# Optional scratch/test override.
# Use this to run the same path/frame logic in a clean copied frame folder,
# without touching an existing production frame directory.
if [[ -n "${LINOG_FRAME_DIR_OVERRIDE:-}" ]]; then
    FRAME_DIR="${LINOG_FRAME_DIR_OVERRIDE}"
fi'''

if old not in s:
    raise SystemExit("Could not find FRAME_DIR block to patch")

s = s.replace(old, new)

p.write_text(s)
PYEOF

chmod +x ~/linog_batch_path_frame_ph0to4_v1_scratch.sh
bash -n ~/linog_batch_path_frame_ph0to4_v1_scratch.sh

grep -n "LINOG_FRAME_DIR_OVERRIDE" -A5 -B5 ~/linog_batch_path_frame_ph0to4_v1_scratch.sh