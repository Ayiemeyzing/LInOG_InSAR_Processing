export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

run_unpack_all_cli.py \
  2>&1 | tee logs/03_unpack_all.log

echo
echo "=== SLC DATES ===" | tee -a logs/03_unpack_all.log
ls -1 SLC | sort | tee logs/03_slc_dates.txt
cat logs/03_slc_dates.txt