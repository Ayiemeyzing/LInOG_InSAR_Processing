export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

sh run_files/run_03_geo2rdr_coarseResamp 2>&1 | tee logs/08_run03_geo2rdr_coarseResamp_no20090811.log