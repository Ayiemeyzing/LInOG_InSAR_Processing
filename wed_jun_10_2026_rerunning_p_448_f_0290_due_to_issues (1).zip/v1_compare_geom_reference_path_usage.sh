grep -RniE "merged/geom_reference|/geom_reference/|coregSLC/Coarse|waterMask|lat.rdr|lon.rdr" \
    /eggraid/home/arieln/projects/linog/insar/P448/f0280 \
    /eggraid/home/arieln/projects/linog/insar/p448/f0280 \
    /eggraid/home/arieln/projects/linog/insar/p448/f0290 \
    2>/dev/null | head -300