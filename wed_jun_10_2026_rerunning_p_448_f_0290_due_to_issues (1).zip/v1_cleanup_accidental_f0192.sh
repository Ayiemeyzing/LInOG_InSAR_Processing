ls -lah /eggraid/home/arieln/projects/linog/insar/p448/f0192 2>/dev/null || true
rm -rf /eggraid/home/arieln/projects/linog/insar/p448/f0192