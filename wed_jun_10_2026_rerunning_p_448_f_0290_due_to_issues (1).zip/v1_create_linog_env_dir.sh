mkdir -p /eggraid/home/arieln/linog_repo/env
ls -ld /eggraid/home/arieln/linog_repo/env