export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

sed -i 's#/eggraid/home/arieln/projects/linog/insar/p448/f280/#/eggraid/home/arieln/projects/linog/insar/p448/f0290/DEM/#g' DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84.vrt
sed -i 's#/eggraid/home/arieln/projects/linog/insar/p448/f280/#/eggraid/home/arieln/projects/linog/insar/p448/f0290/DEM/#g' DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84.xml

echo "=== updated embedded paths ==="
grep -nE "p448|f280|f0290|SourceFilename|vrt" DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84.xml DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84.vrt 2>/dev/null