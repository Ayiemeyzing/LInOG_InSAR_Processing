ARCHIVE_ROOT=/eggraid/home/arieln/projects/linog/insar/p447/archive_f0300_old_runs
ARCHIVE_DIR="$(find "$ARCHIVE_ROOT" -maxdepth 1 -mindepth 1 -type d -name 'f0300_old_products_*' | sort | tail -1)"

echo "ARCHIVE_DIR=$ARCHIVE_DIR"
ls -ld "$ARCHIVE_DIR"