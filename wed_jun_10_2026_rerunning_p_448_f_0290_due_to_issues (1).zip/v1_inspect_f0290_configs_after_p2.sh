export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== reference config ==="
grep -nE "output|lat_file|lon_file|waterMask|geom" configs/config_reference_20091111

echo
echo "=== sample geo2rdr configs ==="
grep -nE "geom|coreg|reference|secondary" configs/config_geo2rdr_coarseResamp_* | head -80

echo
echo "=== sample refineSecondaryTiming configs ==="
grep -nE "reference|secondary|outfile" configs/config_refineSecondaryTiming_* | head -80