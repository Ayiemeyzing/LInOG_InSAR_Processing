SRC=/eggraid/home/arieln/projects/linog/insar/p447/f0300

echo "SRC=$SRC"
ls -ld "$SRC"
ls -ld "$SRC/SLC"
ls -ld "$SRC/DEM"

echo
echo "=== source SLC count ==="
find "$SRC/SLC" -maxdepth 1 -mindepth 1 -type d | wc -l

echo
echo "=== source DEM files ==="
find "$SRC/DEM" -maxdepth 1 -type f | sort