export SRC=/eggraid/home/arieln/projects/linog/insar/P448/f0280
export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290

mkdir -p "${WDIR}/DEM"

cp -v "${SRC}"/demLat_N14_N18_Lon_E120_E123.dem.wgs84* "${WDIR}/DEM/" 2>/dev/null || true
cp -v "${SRC}"/DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84* "${WDIR}/DEM/" 2>/dev/null || true

echo
echo "=== DEM after copy attempt ==="
ls -lah "${WDIR}/DEM"