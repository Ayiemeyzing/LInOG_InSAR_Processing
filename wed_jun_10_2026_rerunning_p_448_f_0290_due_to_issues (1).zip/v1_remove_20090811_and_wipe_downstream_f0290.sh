export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== removing problematic acquisition 20090811 ==="
rm -rf SLC/20090811
rm -rf unzipped/20090811

echo
echo "=== wiping downstream products ==="
rm -rf configs run_files baselines pairs.pdf isce.log
rm -rf merged geom_reference coregSLC offsets refineSecondaryTiming misreg
rm -rf interferograms Igrams
rm -rf rejected_pairs rejected_pairs.log

mkdir -p configs run_files interferograms Igrams logs

echo
echo "=== remaining SLC dates ==="
ls -1 SLC | sort