export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

{
  echo "=== DATE ==="
  date

  echo
  echo "=== HOST ==="
  hostname

  echo
  echo "=== USER ==="
  whoami

  echo
  echo "=== CONDA ==="
  echo "$CONDA_PREFIX"
  conda info --envs

  echo
  echo "=== WHICH TOOLS ==="
  which python
  which stackStripMap.py
  which stripmapWrapper.py
  which refineSecondaryTiming.py
  which geo2rdr.py || true

  echo
  echo "=== ISCE PYTHON ==="
  python -c "import isce; print(isce.__file__)"
  python -c "import isce; print(getattr(isce,'__version__','NO_VERSION_ATTR'))"

  echo
  echo "=== PATH ==="
  echo "$PATH"

  echo
  echo "=== PYTHONPATH ==="
  echo "$PYTHONPATH"
} 2>&1 | tee logs/00_env_snapshot.log