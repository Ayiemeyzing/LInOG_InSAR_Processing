mkdir -p ~/LInOG/insar/p448/f0290/Igrams

rsync -avh --progress \
  arieln@felix:/eggraid/home/arieln/projects/linog/insar/p448/f0290/Igrams/*/*.int* \
  arieln@felix:/eggraid/home/arieln/projects/linog/insar/p448/f0290/Igrams/*/*.amp* \
  arieln@felix:/eggraid/home/arieln/projects/linog/insar/p448/f0290/Igrams/*/*.cor* \
  arieln@felix:/eggraid/home/arieln/projects/linog/insar/p448/f0290/Igrams/*/*.unw* \
  ~/LInOG/insar/p448/f0290/Igrams/