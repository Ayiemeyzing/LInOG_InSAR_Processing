source /eggraid/home/arieln/linog_repo/env/activate_linog_isce2.sh
echo "AFTER ACTIVATE:"
echo "CONDA_PREFIX=$CONDA_PREFIX"
which python3
which gdalinfo
which stackStripMap.py