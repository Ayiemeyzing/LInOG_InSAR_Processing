FRAME_DIR=/eggraid/home/arieln/projects/linog/insar/p447/f0300

echo "FRAME_DIR=$FRAME_DIR"
ls -ld "$FRAME_DIR"

echo
echo "=== top-level contents ==="
find "$FRAME_DIR" -maxdepth 1 -mindepth 1 -printf "%f\n" | sort

echo
echo "=== SLC count ==="
find "$FRAME_DIR/SLC" -maxdepth 1 -mindepth 1 -type d 2>/dev/null | wc -l

echo
echo "=== SLC dates ==="
find "$FRAME_DIR/SLC" -maxdepth 1 -mindepth 1 -type d -printf "%f\n" 2>/dev/null | sort

echo
echo "=== DEM files ==="
find "$FRAME_DIR/DEM" -maxdepth 1 -type f 2>/dev/null | sort

echo
echo "=== Generated products that should NOT exist yet ==="
for d in configs run_files coregSLC Igrams merged offsets refineSecondaryTiming interferograms mintpy; do
    if [[ -e "$FRAME_DIR/$d" ]]; then
        echo "WARNING: generated product exists: $d"
    else
        echo "OK absent: $d"
    fi
done