#!/usr/bin/env bash
set -eo pipefail

TARGET_ENV="/eggraid/miniconda3/envs/linog_isce2"

# Clear conflicting state from personal / legacy environments
unset PYTHONPATH || true
unset ISCE_HOME || true
unset ISCEDB || true

# Only activate if not already in the target env
if [[ "${CONDA_PREFIX:-}" != "$TARGET_ENV" ]]; then
    source /eggraid/miniconda3/etc/profile.d/conda.sh
    conda activate "$TARGET_ENV"
fi

# Canonical ISCE paths from the shared env
export ISCE_HOME="${TARGET_ENV}/lib/python3.11/site-packages/isce"
export PATH="${TARGET_ENV}/share/isce2/stripmapStack:${TARGET_ENV}/lib/python3.11/site-packages/isce/applications:${TARGET_ENV}/lib/python3.11/site-packages/isce/bin:$PATH"
export PYTHONPATH="${TARGET_ENV}/lib/python3.11/site-packages/isce/components:${TARGET_ENV}/share/isce2:${TARGET_ENV}/lib/python3.11/site-packages/isce"

echo "Activated linog_isce2"
echo "CONDA_PREFIX=$CONDA_PREFIX"
echo "python3=$(which python3)"
echo "gdalinfo=$(which gdalinfo)"
echo "stackStripMap.py=$(which stackStripMap.py)"