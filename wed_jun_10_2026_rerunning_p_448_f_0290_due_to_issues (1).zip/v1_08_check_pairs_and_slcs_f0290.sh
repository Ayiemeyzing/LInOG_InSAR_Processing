export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== SLC DATES ==="
ls -1 SLC | sort

echo
echo "=== does 20090626 exist? ==="
ls SLC/20090626 >/dev/null 2>&1 && echo "YES: 20090626 exists" || echo "NO: 20090626 missing"

echo
echo "=== candidate reference dates near center of stack ==="
ls -1 SLC | sort