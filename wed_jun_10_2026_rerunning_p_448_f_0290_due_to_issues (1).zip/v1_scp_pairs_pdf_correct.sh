mkdir -p ~/LInOG/insar/p448/f0290
scp arieln@felix:/eggraid/home/arieln/projects/linog/insar/p448/f0290/pairs.pdf \
  ~/LInOG/insar/p448/f0290/P448F0290_pairs.pdf