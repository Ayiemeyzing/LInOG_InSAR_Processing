echo "=== shell basics ==="
echo "SHELL=$SHELL"
echo "HOSTNAME=$(hostname)"
echo "PWD=$(pwd)"
echo

echo "=== conda ==="
which conda || true
conda info --envs 2>/dev/null || true
echo "CONDA_PREFIX=$CONDA_PREFIX"
echo "CONDA_DEFAULT_ENV=$CONDA_DEFAULT_ENV"
echo

echo "=== executables on PATH ==="
which python || true
which python3 || true
which pip || true
which gdalinfo || true
which stackStripMap.py || true
which stripmapWrapper.py || true
echo

echo "=== versions ==="
python --version 2>/dev/null || true
python3 --version 2>/dev/null || true
gdalinfo --version 2>/dev/null || true
echo

echo "=== env vars ==="
echo "PATH=$PATH"
echo
echo "PYTHONPATH=$PYTHONPATH"
echo
echo "ISCE_HOME=$ISCE_HOME"
echo "ISCEDB=$ISCEDB"
echo

echo "=== python import provenance ==="
python3 - <<'EOF'
import os, sys
print("sys.executable =", sys.executable)
print("sys.prefix     =", sys.prefix)
print("sys.path:")
for p in sys.path:
    print("  ", p)

mods = ["isce", "isceobj", "osgeo", "numpy", "scipy"]
print()
for m in mods:
    try:
        mod = __import__(m)
        print(f"{m}: {getattr(mod, '__file__', '(built-in)')}")
    except Exception as e:
        print(f"{m}: IMPORT FAILED -> {e}")
EOF