export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== coarse directories ==="
find coregSLC/Coarse -maxdepth 2 -type d | sort

echo
echo "=== coarse file sample ==="
find coregSLC/Coarse -maxdepth 2 -type f | sort | head -120

sh run_files/run_04_refineSecondaryTiming 2>&1 | tee logs/09_run04_refineSecondaryTiming.log