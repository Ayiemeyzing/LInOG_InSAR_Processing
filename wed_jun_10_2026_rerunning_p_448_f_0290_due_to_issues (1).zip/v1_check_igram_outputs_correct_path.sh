export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== pwd ==="
pwd

echo
echo "=== top-level dirs ==="
ls -lah

echo
echo "=== interferograms dir ==="
ls -lah interferograms 2>/dev/null || echo "interferograms dir missing"

echo
echo "=== Igrams dir ==="
ls -lah Igrams 2>/dev/null || echo "Igrams dir missing"

echo
echo "=== interferogram count under Igrams ==="
find Igrams -maxdepth 1 -mindepth 1 -type d 2>/dev/null | wc -l

echo
echo "=== sample Igrams dirs ==="
find Igrams -maxdepth 1 -mindepth 1 -type d 2>/dev/null | sort | head -30

echo
echo "=== sample final products anywhere relevant ==="
find Igrams interferograms -type f 2>/dev/null | grep -E "filt_.*\.int$|phsig\.cor$|\.unw$|topophase\.flat$|filt_topophase\.flat$" | head -80