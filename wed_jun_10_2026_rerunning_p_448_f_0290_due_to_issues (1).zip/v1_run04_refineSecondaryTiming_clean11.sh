export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

sh run_files/run_04_refineSecondaryTiming 2>&1 | tee logs/09_run04_refineSecondaryTiming_clean11.log