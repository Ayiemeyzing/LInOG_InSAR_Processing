linog_envinfo() {
    echo "CONDA_PREFIX=$CONDA_PREFIX"
    which python3
    which gdalinfo
    which stackStripMap.py
}