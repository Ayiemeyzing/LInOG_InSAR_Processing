rm -rf /eggraid/home/arieln/projects/linog/insar/p448/f0192

find /eggraid/home/arieln/projects/linog/insar/p448 -maxdepth 1 -type d | sort