set +e
set +u
set +o pipefail

FRAME_DIR=/eggraid/home/arieln/projects/linog/insar/p447/f0300
ARCHIVE_ROOT=/eggraid/home/arieln/projects/linog/insar/p447/archive_f0300_old_runs
ARCHIVE_DIR="${ARCHIVE_ROOT}/f0300_old_products_$(date +%Y%m%d_%H%M%S)"

mkdir -p "$ARCHIVE_DIR"

echo "FRAME_DIR=$FRAME_DIR"
echo "ARCHIVE_DIR=$ARCHIVE_DIR"
echo

for d in \
  baselines \
  configs \
  coregSLC \
  geom_reference \
  Igrams \
  interferograms \
  logs \
  manual_run_logs \
  merged \
  mintpy \
  mintpy_logs \
  offsets \
  refineSecondaryTiming \
  rejected_pairs \
  run_files
do
  if [[ -e "$FRAME_DIR/$d" ]]; then
    echo "Moving $FRAME_DIR/$d -> $ARCHIVE_DIR/$d"
    mv "$FRAME_DIR/$d" "$ARCHIVE_DIR/$d"
  else
    echo "Not present, skipping: $FRAME_DIR/$d"
  fi
done

mkdir -p "$FRAME_DIR/logs"

echo
echo "=== Remaining in frame dir ==="
find "$FRAME_DIR" -maxdepth 1 -mindepth 1 -printf "%f\n" | sort

echo
echo "=== Archived products ==="
find "$ARCHIVE_DIR" -maxdepth 1 -mindepth 1 -printf "%f\n" | sort