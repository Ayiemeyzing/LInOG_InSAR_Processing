set +e
set +u
set +o pipefail

PARENT=/eggraid/home/arieln/projects/linog/insar/p447
OLD_FRAME="${PARENT}/f0300"
ARCHIVE_ROOT="${PARENT}/archive_f0300_old_runs"
ARCHIVE_DIR="${ARCHIVE_ROOT}/f0300_old_products_$(date +%Y%m%d_%H%M%S)"

echo "OLD_FRAME=$OLD_FRAME"
echo "ARCHIVE_DIR=$ARCHIVE_DIR"

if [[ ! -d "$OLD_FRAME" ]]; then
    echo "STOP: old frame directory does not exist: $OLD_FRAME"
else
    mkdir -p "$ARCHIVE_ROOT"
    mv "$OLD_FRAME" "$ARCHIVE_DIR"
    echo "Moved old full frame to:"
    echo "$ARCHIVE_DIR"
fi

echo
echo "=== p447 contents after archive ==="
find "$PARENT" -maxdepth 1 -type d | sort