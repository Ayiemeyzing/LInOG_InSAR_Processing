export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

for p in \
    20091111_20091227 \
    20091111_20100211 \
    20091227_20110214 \
    20070203_20081108
do
    echo "=== $p ==="
    ls -lah Igrams/$p
    echo
done