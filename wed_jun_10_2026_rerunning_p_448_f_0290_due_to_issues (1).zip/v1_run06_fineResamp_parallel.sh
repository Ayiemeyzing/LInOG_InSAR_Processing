export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

parallel -j 4 < run_files/run_06_fineResamp 2>&1 | tee logs/11_run06_fineResamp.log