export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
ls -lah "${WDIR}/DEM"