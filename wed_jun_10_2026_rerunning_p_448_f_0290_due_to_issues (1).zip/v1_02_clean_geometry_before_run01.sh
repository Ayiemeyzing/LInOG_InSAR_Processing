export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

rm -rf merged geom_reference
mkdir -p merged geom_reference