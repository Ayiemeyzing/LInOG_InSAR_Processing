export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

stackStripMap.py -W interferogram --nofocus \
    -s SLC \
    -d DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84 \
    -t 730 -b 1500 -a 28 -r 12 -u snaphu \
    2>&1 | tee logs/05_stack_config_p1.log

echo
echo "=== CONFIG FILES ===" | tee -a logs/05_stack_config_p1.log
ls -1 configs | sort | tee -a logs/05_stack_config_p1.log

echo
echo "=== RUN FILES ===" | tee -a logs/05_stack_config_p1.log
ls -1 run_files 2>/dev/null | sort | tee -a logs/05_stack_config_p1.log