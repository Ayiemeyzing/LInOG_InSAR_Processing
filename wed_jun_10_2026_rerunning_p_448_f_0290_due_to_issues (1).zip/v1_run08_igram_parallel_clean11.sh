export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

parallel -j 4 < run_files/run_08_igram 2>&1 | tee logs/13_run08_igram_clean11.log