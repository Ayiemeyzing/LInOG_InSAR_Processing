export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== sample interferogram files ==="
find interferograms -type f | grep -E "filt_.*\.int$|phsig\.cor$|unw$" | head -40