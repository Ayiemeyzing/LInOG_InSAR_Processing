linog_off() {
    conda deactivate || true
    unset PYTHONPATH || true
    unset ISCE_HOME || true
    unset ISCEDB || true
    echo "LInOG environment cleared."
}