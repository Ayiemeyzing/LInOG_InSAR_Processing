ARCHIVE_DIR=/eggraid/home/arieln/projects/linog/insar/p447/archive_f0300_old_runs/f0300_old_products_20260610_091917

echo "=== archive exists ==="
ls -ld "$ARCHIVE_DIR"

echo
echo "=== archive top-level contents ==="
find "$ARCHIVE_DIR" -maxdepth 1 -mindepth 1 -printf "%f\n" | sort