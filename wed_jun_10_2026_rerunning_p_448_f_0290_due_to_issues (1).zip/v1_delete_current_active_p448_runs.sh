rm -rf /eggraid/home/arieln/projects/linog/insar/p448/f0280
rm -rf /eggraid/home/arieln/projects/linog/insar/p448/f0290

mkdir -p /eggraid/home/arieln/projects/linog/insar/p448/f0280
mkdir -p /eggraid/home/arieln/projects/linog/insar/p448/f0290