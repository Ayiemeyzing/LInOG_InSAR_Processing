export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== run08 Normal Completion count ==="
grep -c "Normal Completion" logs/13_run08_igram_clean11.log

echo
echo "=== run08 errors/warnings ==="
grep -niE "Traceback|Exception|ERROR|No such file|cannot|failed" logs/13_run08_igram_clean11.log | head -200