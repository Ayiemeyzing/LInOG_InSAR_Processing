export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290

rm -rf "${WDIR}"
mkdir -p "${WDIR}"/{raw,unzipped,SLC,DEM,logs,manual_run_logs,interferograms,run_files,Igrams}
cd "${WDIR}"

ln -s raw data

echo "Clean workspace created:"
pwd
ls -lah