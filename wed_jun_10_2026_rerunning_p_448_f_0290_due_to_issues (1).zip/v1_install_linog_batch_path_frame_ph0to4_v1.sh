chmod +x ~/linog_batch_path_frame_ph0to4_v1.sh
ls -l ~/linog_batch_path_frame_ph0to4_v1.sh