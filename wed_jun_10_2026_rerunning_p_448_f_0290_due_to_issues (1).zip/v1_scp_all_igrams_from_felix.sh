mkdir -p ~/LInOG/insar/p448/f0290
scp -r arieln@felix:/eggraid/home/arieln/projects/linog/insar/p448/f0290/Igrams \
  ~/LInOG/insar/p448/f0290/