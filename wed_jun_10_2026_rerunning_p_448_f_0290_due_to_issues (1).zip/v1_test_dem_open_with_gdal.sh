export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

python3 - <<'EOF'
from osgeo import gdal

path = 'DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84.vrt'
ds = gdal.Open(path)
print("GDAL dataset:", ds)
if ds is None:
    raise RuntimeError(f"Failed to open {path}")
print("RasterXSize:", ds.RasterXSize)
print("RasterYSize:", ds.RasterYSize)
EOF