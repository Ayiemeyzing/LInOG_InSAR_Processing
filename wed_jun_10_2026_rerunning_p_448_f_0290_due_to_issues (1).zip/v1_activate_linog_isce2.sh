#!/usr/bin/env bash
set -euo pipefail

unset PYTHONPATH || true
unset ISCE_HOME || true
unset ISCEDB || true

source /eggraid/miniconda3/etc/profile.d/conda.sh
conda activate /eggraid/miniconda3/envs/linog_isce2

export ISCE_HOME="/eggraid/miniconda3/envs/linog_isce2/lib/python3.11/site-packages/isce"
export PATH="/eggraid/miniconda3/envs/linog_isce2/share/isce2/stripmapStack:$PATH"

echo "Activated linog_isce2"
echo "CONDA_PREFIX=$CONDA_PREFIX"
echo "python=$(which python3)"
echo "gdalinfo=$(which gdalinfo)"
echo "stackStripMap.py=$(which stackStripMap.py || true)"