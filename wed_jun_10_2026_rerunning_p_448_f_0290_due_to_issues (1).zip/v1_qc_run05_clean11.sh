export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

grep -niE "RMSE|azimuth|range|misreg|Exception|Traceback|azpoly|rgpoly|valid|failed|skip" \
    logs/10_run05_invertMisreg_clean11.log | head -400