#!/usr/bin/env bash
set -euo pipefail

# 1) start clean
unset PYTHONPATH || true
unset ISCE_HOME || true
unset ISCEDB || true

# 2) activate chosen conda env
source ~/miniconda3/etc/profile.d/conda.sh
conda activate isce2

# 3) set ISCE paths explicitly if needed
# Example only — replace after diagnosis with the real install root
# export ISCE_ROOT="$CONDA_PREFIX/lib/python3.11/site-packages/isce"
# export ISCE_HOME="$ISCE_ROOT"
# export PATH="$ISCE_HOME/applications:$PATH"
# export PYTHONPATH="$ISCE_ROOT:${PYTHONPATH:-}"

# 4) print proof
echo "CONDA_PREFIX=$CONDA_PREFIX"
echo "python=$(which python3)"
echo "stackStripMap.py=$(which stackStripMap.py || true)"

python3 - <<'EOF'
import sys
print("sys.executable =", sys.executable)
import isce, isceobj, osgeo
print("isce    =", isce.__file__)
print("isceobj =", isceobj.__file__)
print("osgeo   =", osgeo.__file__)
EOF