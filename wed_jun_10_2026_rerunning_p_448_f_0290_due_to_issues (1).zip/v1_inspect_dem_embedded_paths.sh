export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== VRT contents ==="
cat DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84.vrt

echo
echo "=== XML path-like lines ==="
grep -nE "p448|f280|f0280|f0290|SourceFilename|file_name|vrt" DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84.xml DEM/demLat_N14_N18_Lon_E120_E123.dem.wgs84.vrt 2>/dev/null