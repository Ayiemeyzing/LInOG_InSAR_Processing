export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

echo "=== before patch ==="
grep -n "createWaterMask" run_files/run_01_reference || true

sed -i '/createWaterMask/d' run_files/run_01_reference

echo
echo "=== after patch ==="
grep -n "createWaterMask" run_files/run_01_reference || echo "createWaterMask removed"