export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

mkdir -p DEM
cd DEM

dem.py -a stitch -b 14 18 120 123 -r -s 1 -c \
  2>&1 | tee ../logs/04_dem.log

cd ..

echo
echo "=== DEM FILES ===" | tee -a logs/04_dem.log
ls -lah DEM | tee -a logs/04_dem.log