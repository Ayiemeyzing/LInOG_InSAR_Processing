echo "BEFORE flags=$-"
set -o | grep -E 'errexit|nounset|pipefail'

linog_isce2

echo "AFTER flags=$-"
set -o | grep -E 'errexit|nounset|pipefail'

echo "Now testing a harmless failing command:"
false
echo "Shell survived false command."

echo "Now testing failed find in pipeline:"
find /definitely/not/a/real/path -maxdepth 1 2>/dev/null | wc -l
echo "Shell survived failed find pipeline."