cat >> ~/.bashrc <<'EOF'

# LInOG shared ISCE2 environment helpers
linog_isce2() {
    source /eggraid/home/arieln/linog_repo/env/activate_linog_isce2.sh && \
    /eggraid/home/arieln/linog_repo/env/check_linog_isce2.sh
}

linog_envinfo() {
    echo "CONDA_PREFIX=$CONDA_PREFIX"
    which python3
    which gdalinfo
    which stackStripMap.py
}
EOF

source ~/.bashrc