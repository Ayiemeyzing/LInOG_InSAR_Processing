FRAME_DIR=/eggraid/home/arieln/projects/linog/insar/p447/f0300

cat > "$FRAME_DIR/README_CLEAN_REBUILD.txt" <<EOF
P447/F0300 clean rebuild started on $(date)

Old full failed run archived at:
/eggraid/home/arieln/projects/linog/insar/p447/archive_f0300_old_runs/f0300_old_products_20260610_091917

This active folder was recreated from scratch.

Policy:
- Do not copy generated products from the old archived run.
- Rebuild raw -> unzipped -> SLC -> DEM -> stackStripMap products cleanly.
- Use linog_isce2 environment only.
EOF

cat "$FRAME_DIR/README_CLEAN_REBUILD.txt"