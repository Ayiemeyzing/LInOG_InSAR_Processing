export WDIR=/eggraid/home/arieln/projects/linog/insar/p448/f0290
cd "${WDIR}"

for d in Igrams/*; do
    [ -d "$d" ] || continue
    pair=$(basename "$d")
    ok=1
    for f in \
        "$d/filt_${pair}.int" \
        "$d/filt_${pair}.cor" \
        "$d/filt_${pair}_snaphu.unw" \
        "$d/filt_${pair}_snaphu.unw.conncomp"
    do
        [ -f "$f" ] || { echo "MISSING $f"; ok=0; }
    done
    [ $ok -eq 1 ] && echo "OK $pair"
done | tee logs/14_igram_completeness.log