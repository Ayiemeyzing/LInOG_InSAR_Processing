echo "=== clone basic paths ==="
ls -ld /eggraid/miniconda3/envs/linog_isce2
ls -ld /eggraid/miniconda3/envs/linog_isce2/bin
ls -ld /eggraid/miniconda3/envs/linog_isce2/share 2>/dev/null || true
echo

echo "=== important executables in clone ==="
find /eggraid/miniconda3/envs/linog_isce2 -type f \( \
    -name "python" -o \
    -name "python3" -o \
    -name "gdalinfo" -o \
    -name "stackStripMap.py" -o \
    -name "stripmapWrapper.py" -o \
    -name "createWaterMask.py" -o \
    -name "invertMisreg.py" \
\) 2>/dev/null | sort
echo

echo "=== clone python provenance ==="
/eggraid/miniconda3/envs/linog_isce2/bin/python3 - <<'EOF'
import sys
print("sys.executable =", sys.executable)
print("sys.prefix     =", sys.prefix)
mods = ["isce", "isceobj", "osgeo", "numpy", "scipy"]
for m in mods:
    try:
        mod = __import__(m)
        print(f"{m}: {getattr(mod, '__file__', '(built-in)')}")
    except Exception as e:
        print(f"{m}: IMPORT FAILED -> {e}")
EOF