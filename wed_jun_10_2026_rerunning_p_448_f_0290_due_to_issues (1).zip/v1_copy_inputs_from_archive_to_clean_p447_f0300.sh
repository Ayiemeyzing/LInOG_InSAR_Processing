set +e
set +u
set +o pipefail

PARENT=/eggraid/home/arieln/projects/linog/insar/p447
NEW_FRAME="${PARENT}/f0300"
ARCHIVE_ROOT="${PARENT}/archive_f0300_old_runs"
ARCHIVE_DIR="$(find "$ARCHIVE_ROOT" -maxdepth 1 -mindepth 1 -type d -name 'f0300_old_products_*' | sort | tail -1)"

echo "ARCHIVE_DIR=$ARCHIVE_DIR"
echo "NEW_FRAME=$NEW_FRAME"

for d in SLC DEM raw unzipped; do
    if [[ -d "$ARCHIVE_DIR/$d" ]]; then
        echo "Copying $d ..."
        mkdir -p "$NEW_FRAME/$d"
        rsync -aH "$ARCHIVE_DIR/$d/" "$NEW_FRAME/$d/"
    else
        echo "Archive does not contain $d, skipping."
    fi
done

mkdir -p "$NEW_FRAME/logs"

echo
echo "=== clean active f0300 contents ==="
find "$NEW_FRAME" -maxdepth 2 -type d | sort